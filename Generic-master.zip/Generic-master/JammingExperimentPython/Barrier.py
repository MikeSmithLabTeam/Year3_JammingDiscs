# -*- coding: utf-8 -*-
"""
Created on Tue Aug 14 10:49:19 2018

@author: ppzmis
"""


import sys
#import glob
import serial
import time
#import struct


 
def open_serial_port(comport='COM4'):
    """Open the selected serial port"""
    #self.port_status = False
    #comport = serial_port_choice
    #print(comport)
    port = serial.Serial()
    port.port = comport
    port.baudrate = 9600
    port.timeout = 0
    if port.isOpen() == False:
       port.open()
       port_status = True
       time.sleep(2)
       print('port opened')
    else:
       print("Select a COMPORT")
    return port
    
def quit_serial(port):
    """Method to close the serial port when the Tk window is closed"""
    port.close()
    
        
def sendCommand(serialObj,cmd,pos=0,steps=0):
    '''
    The barriers move by sending messages to the arduino code newStepperBoard which handles the hardware. 
    The commands are as follows.
    
    RX - Reset the X barrier position to zero by moving until it hits the limit switch
    RY - Reset the Y barrier position to zero by moving until it hits the limit switch
    MX+10 - Move X barrier towards middle by 10 steps
    MX-10 - Move barrier towards end by 10 steps
    MY+10 - Move Y barrier towards the middle by 10 steps
    MY-10 - Move Y barrier towards the end by 10 steps
    
    To enter the command supply a string to cmd of RX,RY, MX+,MX-,MY+,MY- etc
    Supply the current position
    Supply the number of steps to move
    
    Function returns the new position
    '''

    
    if cmd =='RX':
        print('RX')
        serialObj.write(b'RX\n')
        pos = 0
    if cmd =='RY':
        print('RY')
        serialObj.write(b'RY\n')
        pos=0
    if cmd =='MX+':
        print('MX+')
        message  = b'MX+'
        serialObj.write(message)
        serialObj.write(bytes(str(steps),'utf8'))
        serialObj.write(b'\n')
        pos=pos + steps
    if cmd =='MX-':
        print('MX-')
        message  = b'MX-'
        serialObj.write(message)
        serialObj.write(bytes(str(steps),'utf8'))
        serialObj.write(b'\n')
        pos=pos - steps
    if cmd =='MY+':
        print('MY+')
        message  = b'MY+'
        serialObj.write(message)
        serialObj.write(bytes(str(steps),'utf8'))
        serialObj.write(b'\n')
        pos=pos + steps
    if cmd =='MY-':
        print('MY-')
        message  = b'MY-'
        serialObj.write(message)
        serialObj.write(bytes(str(steps),'utf8'))
        serialObj.write(b'\n')
        pos=pos - steps
    
          
    print('values written')
    time.sleep(0.5)
    return pos

 
    
if __name__ == '__main__':
    try:
        quit_serial(s)
    except:
        pass
    s=open_serial_port()
    
    #Reset x barrier
    xpos=sendCommand(s,'RX')
    xpos=0
        
    #Move x barrier 2000 steps towards the middle
    #xpos=sendCommand(s,'MX-',pos=xpos,steps=2000)
    
    quit_serial(s)
    
        