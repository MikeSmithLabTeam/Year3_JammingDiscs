import CameraControl
import Video
import Stepper
import time


if __name__ == '__main__':
    try:
        web_cam.close()
        barrier.close()
    except:
        pass
    numbSteps = 260 # Number of steps to take total
    step = 20 # Number of steps each time
    limit = 5200 # max number of steps barrier can move before destroying lid!

    barrier = Stepper.DualStepper(comport='COM4')
    barrier.send_command('RX')

    
    web_cam = CameraControl.Camera(cam_type = 'logitechHD1080p',frame_size = -1)
    web_cam.set_cam_props('brightness', 50)
    web_cam.set_cam_props('exposure', -5)
    # web_cam.set_cam_props('saturation', 100)
    web_cam.set_cam_props('gain', 1)
    web_cam.set_cam_props('contrast', 20)
    web_cam.get_cam_props(show=True)


    web_cam.preview()
    
    web_cam.write_to_vid()
    
    for i in range(numbSteps):
        #capture single frame and write to video
        web_cam.single_pic_vid(show_pic=True)
        time.sleep(0.05)
        #Move step forward
        barrier.send_command('MX+',steps=step)
        
        if barrier.posx >= limit:
            break
    
    web_cam.close_write_vid()
    web_cam.close()
    barrier.close()

    
