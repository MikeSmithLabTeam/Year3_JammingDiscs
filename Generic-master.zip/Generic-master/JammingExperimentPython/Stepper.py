# -*- coding: utf-8 -*-
"""
Created on Tue Aug 14 10:49:19 2018

@author: ppzmis
"""


import sys
import serial
import time


class DualStepper:
 
    def __init__(self,comport='COM4'):
        """Open the selected serial port"""
        self.port = serial.Serial()
        self.port.port = comport
        self.port.baudrate = 9600
        self.port.timeout = 0
        self.posy=0
        self.posx=0
        if self.port.isOpen() == False:
            self.port.open()
            self.port_status = True
            time.sleep(2)
            print('port opened')
        else:
            print("Select a COMPORT")
        
    
    def quit_serial(self):
        """Method to close the serial port when the Tk window is closed"""
        self.port.close()
        time.sleep(1)
        
        
    def send_command(self,cmd,steps=0):
        '''
        The barriers move by sending messages to the arduino code newStepperBoard which handles the hardware. 
        The commands are as follows.
    
        RX - Reset the X barrier position to zero by moving until it hits the limit switch
        RY - Reset the Y barrier position to zero by moving until it hits the limit switch
        MX+10 - Move X barrier towards middle by 10 steps
        MX-10 - Move barrier towards end by 10 steps
        MY+10 - Move Y barrier towards the middle by 10 steps
        MY-10 - Move Y barrier towards the end by 10 steps
    
        To enter the command supply a string to cmd of RX,RY, MX+,MX-,MY+,MY- etc
        Supply the number of steps to move
    
        Function returns the new position
        '''

    
        if cmd =='RX':
            print('RX')
            self.posy=0
            self.port.write(b'RX\n')

        if cmd =='RY':
            print('RY')
            self.posy=0
            self.port.write(b'RY\n')

        if cmd =='MX+':
            print('MX+')
            message  = b'MX+'
            self.port.write(message)
            self.port.write(bytes(str(steps),'utf8'))
            self.port.write(b'\n')
            self.posx=self.posx + steps
        if cmd =='MX-':
            print('MX-')
            message  = b'MX-'
            self.port.write(message)
            self.port.write(bytes(str(steps),'utf8'))
            self.port.write(b'\n')
            self.posx=self.posx - steps
        if cmd =='MY+':
            print('MY+')
            message  = b'MY+'
            self.port.write(message)
            self.port.write(bytes(str(steps),'utf8'))
            self.port.write(b'\n')
            self.posy=self.posy + steps
        if cmd =='MY-':
            print('MY-')
            message  = b'MY-'
            self.port.write(message)
            self.port.write(bytes(str(steps),'utf8'))
            self.port.write(b'\n')
            self.posy=self.posy - steps
    
          
        print('values written')
        time.sleep(0.5)
        

 
    
if __name__ == '__main__':

    s=DualStepper()
    
    #Reset y barrier
    s.send_command('RY')

        
    #Move y barrier 2000 steps towards the middle
    s.send_command('MY+',steps=0)
    
    s.quit_serial()
    
        